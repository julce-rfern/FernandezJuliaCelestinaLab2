package com.lab02;
public class Dog 
{
	private String name,breed,color;
	private int ageyr,agemth,bday,bmth;
	private char gender;
	
	public Dog()	{}
	
	public Dog(String name,String breed,String color,int ageyr,int agemth,int bday,int bmth,
				char gender)
	{
		this.name=name;
		this.breed=breed;
		this.color=color;
		this.ageyr=ageyr;
		this.agemth=agemth;
		this.bday=bday;
		this.bmth=bmth;
		this.gender=gender;
		String gend;
		if(gender=='f'||gender=='F') gend="girl"; else gend="boy"; 
		System.out.println("Who's a good "+gend+"?!");
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public void setBreed(String breed)
	{
		this.breed=breed;
	}
	public void setColor(String color)
	{
		this.color=color;
	}
	public void setAgeyr(int ageyr)
	{
		this.ageyr=ageyr;
	}
	public void setAgemth(int agemth)
	{
		this.agemth=agemth;
	}
	public void setBday(int bday)
	{
		this.bday=bday;
	}
	public void setBmth(int bmth)
	{
		this.bmth=bmth;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
	
	public String getName()
	{
		return this.name;
	}
	public String getBreed()
	{
		return this.breed;
	}
	public String getColor()
	{
		return this.color;
	}
	public int getAgeyr()
	{
		return this.ageyr;
	}
	public int getAgemth()
	{
		return this.agemth;
	}
	public int getBday()
	{
		return this.bday;
	}
	public int getBmth()
	{
		return this.bmth;
	}
	public char getGender()
	{
		return this.gender;
	}
	
	void tricks(String trck)
	{
		System.out.println("This dog knows how to "+trck+".");
	}
	
	void tricks(String trck1,String trck2)
	{
		System.out.println("This dog knows how to "+trck1+" and "+trck2+".");
	}
}

