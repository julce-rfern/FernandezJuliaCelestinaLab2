package com.lab02;

public class DogShow extends Dog
{
	private String group,event,award;
	
	public DogShow()	{}
	
	public DogShow(String name,String breed,String color,int ageyr,int agemth,int bday,int bmth,char gender,String group,String event,String award) 
	{
		super(name,breed,color,ageyr,agemth,bday,bmth,gender);
		this.group=group;
		this.event=event;
		this.award=award;
		System.out.println("20XX DOGSHOW EVENT: "+event);
	}
	
	public void setGroup(String group)
	{
		this.group=group;
	}
	public void setEvent(String event)
	{
		this.event=event;
	}
	public void setAward(String award)
	{
		this.award=award;
	}
	
	public String getGroup()
	{
		return this.group;
	}
	public String getEvent()
	{
		return this.event;
	}
	public String getAward()
	{
		return this.award;
	}
	
	void tricks(String trck)
	{
		System.out.println("This dog performed "+trck+" in the talent show.");
	}
	
	void tricks(String trck1,String trck2)
	{
		System.out.println("This dog performed "+trck1+" and "+trck2+" in the talent show.");
	}
}
