package com.lab02;

public class Test {

	public static void main(String[] args) 
	{
		Dog dog1=new Dog();
		
		dog1.setName("Lili");
		dog1.setBreed("Golden Retriever");
		dog1.setColor("gold");
		dog1.setAgeyr(1);
		dog1.setAgemth(2);
		dog1.setBday(1);
		dog1.setBmth(1);
		dog1.setGender('F');
		
		System.out.println("Name: "+dog1.getName());
		System.out.println("Gender: "+dog1.getGender());
		System.out.println("Breed: "+dog1.getBreed());
		System.out.println("Color: "+dog1.getColor());
		System.out.println("Age: "+dog1.getAgeyr()+" year/s and "+dog1.getAgemth()+" month/s");
		System.out.println("Birthday: "+dog1.getBmth()+"/"+dog1.getBday());
		
		dog1.tricks("fetch");
		
		System.out.println("\n");
		
		Dog dog2=new Dog("Ham","Poodle","white",0,5,22,10,'M');
		
		System.out.println("Name: "+dog2.getName());
		System.out.println("Gender: "+dog2.getGender());
		System.out.println("Breed: "+dog2.getBreed());
		System.out.println("Color: "+dog2.getColor());
		System.out.println("Age: "+dog2.getAgeyr()+" year/s and "+dog2.getAgemth()+" month/s");
		System.out.println("Birthday: "+dog2.getBmth()+"/"+dog2.getBday());
		
		dog2.tricks("fetch","roll over");
		
		System.out.println("\n");
		
		DogShow ds1=new DogShow("Niko","Akita","cream",0,6,3,7,'M',"Working","Dog Agility","Yellow");
		
		System.out.println("Candidate for the "+ds1.getEvent()+" of the "+ds1.getGroup()+" Group:");
		System.out.println("Name: "+ds1.getName());
		System.out.println("Gender: "+ds1.getGender());
		System.out.println("Breed: "+ds1.getBreed());
		System.out.println("Color: "+ds1.getColor());
		System.out.println("Age: "+ds1.getAgeyr()+" year/s and "+ds1.getAgemth()+" month/s");
		System.out.println("Birthday: "+ds1.getBmth()+"/"+ds1.getBday());
		
		ds1.tricks("play dead");
		System.out.println("\nRibbon: "+ds1.getAward());
		
		System.out.println("\n");
		
		DogShow ds2=new DogShow();
		
		ds2.setName("Chibog");
		ds2.setBreed("Greyhound");
		ds2.setColor("gold");
		ds2.setAgeyr(0);
		ds2.setAgemth(8);
		ds2.setBday(9);
		ds2.setBmth(5);
		ds2.setGender('F');
		ds2.setEvent("Dog Agility");
		ds2.setGroup("Hound");
		ds2.setAward("Red, White and Blue");
		
		
		System.out.println("Candidate for the "+ds2.getEvent()+" of the "+ds2.getGroup()+" Group:");
		System.out.println("Name: "+ds2.getName());
		System.out.println("Gender: "+ds2.getGender());
		System.out.println("Breed: "+ds2.getBreed());
		System.out.println("Color: "+ds2.getColor());
		System.out.println("Age: "+ds2.getAgeyr()+" year/s and "+ds2.getAgemth()+" month/s");
		System.out.println("Birthday: "+ds2.getBmth()+"/"+ds2.getBday());
		
		ds1.tricks("speak","sit");
		System.out.println("\nRibbon: "+ds2.getAward());
	}
}
